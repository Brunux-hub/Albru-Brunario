export { default as VentasPanel } from './VentasPanel';
export { default as TendenciasTab } from './TendenciasTab';
export { default as ProductosTab } from './ProductosTab';
export { default as CanalesTab } from './CanalesTab';
export { default as ComparativoTab } from './ComparativoTab';