export { default as ValidacionesSidebar } from './ValidacionesSidebar';
export { default as ValidacionesDashboard } from './ValidacionesDashboard';
export { default as ValidacionesSummary } from './ValidacionesSummary';
export { default as ValidacionesTable } from './ValidacionesTable';
export { default as ValidacionesBusqueda } from './ValidacionesBusqueda';
export { default as ValidacionesProceso } from './ValidacionesProceso';