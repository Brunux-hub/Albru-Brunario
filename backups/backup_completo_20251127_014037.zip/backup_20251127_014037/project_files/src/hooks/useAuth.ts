// Este archivo ahora solo re-exporta desde AppContext para backward compatibility
export { useAuth, useClientes, useApp } from '../context/AppContext';
