import React from 'react';
import AdminPanel from '../components/admin/AdminPanel';

const AdminDashboard: React.FC = () => {
  return <AdminPanel />;
};

export default AdminDashboard;
