import React from 'react';
import AsesorPanel from '../components/asesor/AsesorPanel';

const AsesorDashboard: React.FC = () => {
  return <AsesorPanel />;
};

export default AsesorDashboard;
